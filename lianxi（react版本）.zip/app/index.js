import React from 'react';
import ReactDom from 'react-dom';
import Tobu from './containers/tobu/index'

ReactDom.render(
    <Tobu/>,
    document.getElementById("root")
)